
  # Design Key Screens

  This is a code bundle for Design Key Screens. The original project is available at https://www.figma.com/design/607TInPSE19x0nYtvrkvgP/Design-Key-Screens.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  