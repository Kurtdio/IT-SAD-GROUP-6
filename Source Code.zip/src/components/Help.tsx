import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import { Search, Book, MessageCircle, Mail, ExternalLink } from 'lucide-react';
import { motion } from 'motion/react';

export default function Help() {
  const faqs = [
    {
      question: 'How do I create a new project?',
      answer: 'To create a new project, navigate to the Projects page and click the "New Project" button in the top right corner. Fill in the project details such as name, description, and due date, then click "Create Project".'
    },
    {
      question: 'How can I invite team members?',
      answer: 'Go to your project settings and click on "Team Members". Then click "Invite Member" and enter their email address. They will receive an invitation link to join your project.'
    },
    {
      question: 'Can I export my project data?',
      answer: 'Yes, you can export your project data by going to Settings > Data & Privacy. Click on "Export Data" and select the projects you want to export. You\'ll receive a download link via email.'
    },
    {
      question: 'How do I change my notification settings?',
      answer: 'Navigate to Settings > Notifications to customize your notification preferences. You can choose which types of notifications you want to receive and how you want to receive them.'
    },
    {
      question: 'What happens when a project reaches its deadline?',
      answer: 'When a project reaches its deadline, you\'ll receive a notification. The project will be marked as overdue in your dashboard, but you can continue working on it. You can also extend the deadline from the project settings.'
    },
    {
      question: 'How do I delete a project?',
      answer: 'To delete a project, open the project, click on the three dots menu, and select "Delete Project". Note that this action is permanent and cannot be undone.'
    },
    {
      question: 'Can I recover deleted tasks?',
      answer: 'Deleted tasks are moved to the trash and can be recovered within 30 days. After 30 days, they are permanently deleted. To recover a task, go to your trash folder and click "Restore".'
    },
    {
      question: 'How do I upgrade my account?',
      answer: 'To upgrade your account, go to Settings > Billing and select the plan that best fits your needs. You can upgrade, downgrade, or cancel your subscription at any time.'
    }
  ];

  const resources = [
    {
      title: 'Documentation',
      description: 'Comprehensive guides and API references',
      icon: Book,
      link: '#'
    },
    {
      title: 'Community Forum',
      description: 'Connect with other users and share tips',
      icon: MessageCircle,
      link: '#'
    },
    {
      title: 'Contact Support',
      description: 'Get help from our support team',
      icon: Mail,
      link: '#'
    }
  ];

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-slate-900 mb-2">Help Center</h1>
          <p className="text-slate-600">Find answers and get support</p>
        </div>

        {/* Search */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="mb-8"
        >
          <Card>
            <CardContent className="p-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                <Input
                  placeholder="Search for help..."
                  className="pl-10"
                />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Resources */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {resources.map((resource, index) => {
            const Icon = resource.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Card className="hover:shadow-lg transition-all duration-300 cursor-pointer hover:-translate-y-1">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center mb-4">
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <h3 className="text-slate-900 mb-2">{resource.title}</h3>
                    <p className="text-slate-600 mb-4">{resource.description}</p>
                    <Button variant="ghost" className="text-blue-600 hover:text-blue-700 p-0">
                      Learn more
                      <ExternalLink className="ml-2 h-4 w-4" />
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* FAQs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.3 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Frequently Asked Questions</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                {faqs.map((faq, index) => (
                  <AccordionItem key={index} value={`item-${index}`}>
                    <AccordionTrigger className="text-slate-900 hover:text-blue-600">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-slate-600">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        </motion.div>

        {/* Contact Support */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.4 }}
          className="mt-8"
        >
          <Card className="bg-gradient-to-br from-blue-600 to-indigo-600 text-white border-0">
            <CardContent className="p-8 text-center">
              <h2 className="mb-2">Still need help?</h2>
              <p className="mb-6 text-blue-100">
                Our support team is here to help you with any questions or issues.
              </p>
              <Button className="bg-white text-blue-600 hover:bg-blue-50">
                Contact Support
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
