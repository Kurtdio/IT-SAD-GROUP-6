import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { TrendingUp, TrendingDown, FolderKanban, CheckCircle2, Clock, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

export default function Dashboard() {
  const stats = [
    {
      title: 'Total Projects',
      value: '24',
      change: '+12%',
      trending: 'up',
      icon: FolderKanban,
      color: 'from-blue-600 to-indigo-600'
    },
    {
      title: 'Completed Tasks',
      value: '152',
      change: '+8%',
      trending: 'up',
      icon: CheckCircle2,
      color: 'from-green-600 to-emerald-600'
    },
    {
      title: 'In Progress',
      value: '37',
      change: '-3%',
      trending: 'down',
      icon: Clock,
      color: 'from-amber-600 to-orange-600'
    },
    {
      title: 'Pending Review',
      value: '8',
      change: '+2%',
      trending: 'up',
      icon: AlertCircle,
      color: 'from-purple-600 to-pink-600'
    }
  ];

  const projectData = [
    { name: 'Mon', tasks: 12 },
    { name: 'Tue', tasks: 19 },
    { name: 'Wed', tasks: 15 },
    { name: 'Thu', tasks: 25 },
    { name: 'Fri', tasks: 22 },
    { name: 'Sat', tasks: 8 },
    { name: 'Sun', tasks: 5 }
  ];

  const performanceData = [
    { month: 'Jan', value: 65 },
    { month: 'Feb', value: 72 },
    { month: 'Mar', value: 68 },
    { month: 'Apr', value: 80 },
    { month: 'May', value: 85 },
    { month: 'Jun', value: 92 }
  ];

  const recentProjects = [
    { name: 'Website Redesign', status: 'In Progress', progress: 65, dueDate: 'Dec 15' },
    { name: 'Mobile App', status: 'Review', progress: 90, dueDate: 'Dec 10' },
    { name: 'Marketing Campaign', status: 'Planning', progress: 30, dueDate: 'Dec 20' },
    { name: 'API Integration', status: 'Completed', progress: 100, dueDate: 'Dec 5' }
  ];

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-slate-900 mb-2">Dashboard</h1>
          <p className="text-slate-600">Welcome back! Here's what's happening with your projects.</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Card className="hover:shadow-lg transition-shadow duration-300">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-lg flex items-center justify-center`}>
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <div className={`flex items-center gap-1 ${stat.trending === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                        {stat.trending === 'up' ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                        <span>{stat.change}</span>
                      </div>
                    </div>
                    <h3 className="text-slate-900">{stat.value}</h3>
                    <p className="text-slate-600">{stat.title}</p>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>Weekly Task Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={projectData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="name" stroke="#64748b" />
                    <YAxis stroke="#64748b" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#fff', 
                        border: '1px solid #e2e8f0',
                        borderRadius: '8px'
                      }} 
                    />
                    <Bar dataKey="tasks" fill="url(#colorGradient)" radius={[8, 8, 0, 0]} />
                    <defs>
                      <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#3b82f6" />
                        <stop offset="100%" stopColor="#6366f1" />
                      </linearGradient>
                    </defs>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>Performance Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="month" stroke="#64748b" />
                    <YAxis stroke="#64748b" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#fff', 
                        border: '1px solid #e2e8f0',
                        borderRadius: '8px'
                      }} 
                    />
                    <Line 
                      type="monotone" 
                      dataKey="value" 
                      stroke="#3b82f6" 
                      strokeWidth={3}
                      dot={{ fill: '#3b82f6', r: 4 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Recent Projects */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Recent Projects</CardTitle>
                <Button variant="outline" size="sm">View All</Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentProjects.map((project, index) => (
                  <div
                    key={index}
                    className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors"
                  >
                    <div className="flex-1 mb-3 sm:mb-0">
                      <h4 className="text-slate-900 mb-1">{project.name}</h4>
                      <div className="flex items-center gap-3 text-slate-600">
                        <span className={`px-2 py-1 rounded text-white ${
                          project.status === 'Completed' ? 'bg-green-600' :
                          project.status === 'In Progress' ? 'bg-blue-600' :
                          project.status === 'Review' ? 'bg-purple-600' :
                          'bg-slate-600'
                        }`}>
                          {project.status}
                        </span>
                        <span>Due: {project.dueDate}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex-1 min-w-[200px]">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-slate-600">Progress</span>
                          <span className="text-slate-900">{project.progress}%</span>
                        </div>
                        <div className="w-full bg-slate-200 rounded-full h-2">
                          <div
                            className="bg-gradient-to-r from-blue-600 to-indigo-600 h-2 rounded-full transition-all duration-500"
                            style={{ width: `${project.progress}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
