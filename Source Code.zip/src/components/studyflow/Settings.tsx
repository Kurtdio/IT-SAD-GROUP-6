import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Switch } from '../ui/switch';
import { ArrowLeft, Bell, Moon, Globe, Lock, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';

export default function Settings() {
  const navigate = useNavigate();

  const settingsSections = [
    {
      title: 'Notifications',
      icon: Bell,
      settings: [
        { label: 'Push Notifications', description: 'Receive notifications on your device', enabled: true },
        { label: 'Task Reminders', description: 'Get reminded about upcoming deadlines', enabled: true },
        { label: 'Email Notifications', description: 'Receive updates via email', enabled: false },
        { label: 'Daily Summary', description: 'Get a daily summary of your tasks', enabled: true },
      ]
    },
    {
      title: 'Appearance',
      icon: Moon,
      settings: [
        { label: 'Dark Mode', description: 'Switch to dark theme', enabled: false },
        { label: 'Compact View', description: 'Show more content on screen', enabled: false },
      ]
    },
    {
      title: 'General',
      icon: Globe,
      settings: [
        { label: 'Auto-save', description: 'Automatically save your changes', enabled: true },
        { label: 'Show Completed Tasks', description: 'Display completed tasks in lists', enabled: true },
      ]
    },
    {
      title: 'Privacy & Security',
      icon: Lock,
      settings: [
        { label: 'Biometric Login', description: 'Use fingerprint or face ID to login', enabled: false },
        { label: 'Two-Factor Authentication', description: 'Add extra security to your account', enabled: false },
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      {/* Header */}
      <div className="bg-white pt-12 pb-6 px-4 border-b border-[#E5E7EB]">
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              onClick={() => navigate(-1)}
              className="w-10 h-10 p-0 rounded-xl hover:bg-[#F5F7FA]"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <h1 className="text-[#1E1E1E]">Settings</h1>
          </div>
        </div>
      </div>

      <div className="max-w-screen-xl mx-auto px-4 py-6 space-y-6">
        {settingsSections.map((section, sectionIndex) => {
          const Icon = section.icon;
          return (
            <motion.div
              key={sectionIndex}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: sectionIndex * 0.1 }}
            >
              <Card className="p-6 bg-white rounded-2xl border-0 shadow-sm">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-[#007AFF]/10 rounded-xl flex items-center justify-center">
                    <Icon className="w-5 h-5 text-[#007AFF]" />
                  </div>
                  <h3 className="text-[#1E1E1E]">{section.title}</h3>
                </div>

                <div className="space-y-4">
                  {section.settings.map((setting, settingIndex) => (
                    <div
                      key={settingIndex}
                      className={`flex items-center justify-between py-3 ${
                        settingIndex !== section.settings.length - 1 ? 'border-b border-[#E5E7EB]' : ''
                      }`}
                    >
                      <div className="flex-1">
                        <div className="text-[#1E1E1E] mb-1">{setting.label}</div>
                        <div className="text-sm text-[#6B7280]">{setting.description}</div>
                      </div>
                      <Switch defaultChecked={setting.enabled} />
                    </div>
                  ))}
                </div>
              </Card>
            </motion.div>
          );
        })}

        {/* Account Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.4 }}
        >
          <Card className="p-6 bg-white rounded-2xl border-0 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-[#FF3B30]/10 rounded-xl flex items-center justify-center">
                <Trash2 className="w-5 h-5 text-[#FF3B30]" />
              </div>
              <h3 className="text-[#1E1E1E]">Account</h3>
            </div>

            <div className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full h-12 rounded-xl border-2 border-[#E5E7EB] hover:border-[#FF3B30] hover:bg-[#FF3B30]/5 text-[#FF3B30]"
              >
                Clear All Data
              </Button>
              <Button 
                variant="outline" 
                className="w-full h-12 rounded-xl border-2 border-[#E5E7EB] hover:border-[#FF3B30] hover:bg-[#FF3B30]/5 text-[#FF3B30]"
              >
                Delete Account
              </Button>
            </div>
          </Card>
        </motion.div>

        {/* App Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.5 }}
          className="text-center text-[#6B7280] pb-6"
        >
          <p>StudyFlow v1.0.0</p>
          <p className="mt-1">© 2025 StudyFlow. All rights reserved.</p>
        </motion.div>
      </div>
    </div>
  );
}
