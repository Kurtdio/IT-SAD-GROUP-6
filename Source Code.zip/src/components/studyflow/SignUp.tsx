import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { GraduationCap, Mail, Lock, User, School } from 'lucide-react';
import { motion } from 'motion/react';

interface SignUpProps {
  setIsAuthenticated: (value: boolean) => void;
}

export default function SignUp({ setIsAuthenticated }: SignUpProps) {
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [school, setSchool] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsAuthenticated(true);
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-[#F5F7FA] flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-md"
      >
        <div className="bg-white rounded-3xl shadow-lg p-8">
          {/* Logo */}
          <div className="flex items-center justify-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-[#007AFF] to-[#0051D5] rounded-2xl flex items-center justify-center shadow-lg">
              <GraduationCap className="w-9 h-9 text-white" />
            </div>
          </div>

          <h1 className="text-center text-[#1E1E1E] mb-2">Join StudyFlow</h1>
          <p className="text-center text-[#6B7280] mb-8">
            Create an account to start organizing your studies
          </p>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <Label htmlFor="name" className="text-[#1E1E1E]">Full Name</Label>
              <div className="relative mt-2">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-[#6B7280]" />
                <Input
                  id="name"
                  type="text"
                  placeholder="John Doe"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="pl-12 h-12 rounded-xl border-2 border-[#E5E7EB] focus:border-[#007AFF] transition-colors"
                  required
                />
              </div>
            </div>

            <div>
              <Label htmlFor="email" className="text-[#1E1E1E]">Email</Label>
              <div className="relative mt-2">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-[#6B7280]" />
                <Input
                  id="email"
                  type="email"
                  placeholder="student@university.edu"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-12 h-12 rounded-xl border-2 border-[#E5E7EB] focus:border-[#007AFF] transition-colors"
                  required
                />
              </div>
            </div>

            <div>
              <Label htmlFor="school" className="text-[#1E1E1E]">School/University</Label>
              <div className="relative mt-2">
                <School className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-[#6B7280]" />
                <Input
                  id="school"
                  type="text"
                  placeholder="University Name"
                  value={school}
                  onChange={(e) => setSchool(e.target.value)}
                  className="pl-12 h-12 rounded-xl border-2 border-[#E5E7EB] focus:border-[#007AFF] transition-colors"
                  required
                />
              </div>
            </div>

            <div>
              <Label htmlFor="password" className="text-[#1E1E1E]">Password</Label>
              <div className="relative mt-2">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-[#6B7280]" />
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-12 h-12 rounded-xl border-2 border-[#E5E7EB] focus:border-[#007AFF] transition-colors"
                  required
                />
              </div>
            </div>

            <Button
              type="submit"
              className="w-full h-12 bg-[#007AFF] hover:bg-[#0051D5] text-white rounded-xl transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98] shadow-lg"
            >
              Create Account
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-[#6B7280]">
              Already have an account?{' '}
              <Link to="/login" className="text-[#007AFF] hover:underline transition-all">
                Log in
              </Link>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
