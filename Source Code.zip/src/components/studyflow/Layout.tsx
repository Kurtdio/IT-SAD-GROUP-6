import { Outlet, Link, useLocation } from 'react-router-dom';
import { Home, Calendar, BarChart3, User, Plus } from 'lucide-react';
import { Button } from '../ui/button';

interface LayoutProps {
  isAuthenticated: boolean;
  setIsAuthenticated: (value: boolean) => void;
}

export default function Layout({ isAuthenticated }: LayoutProps) {
  const location = useLocation();

  const navItems = [
    { path: '/dashboard', icon: Home, label: 'Home' },
    { path: '/tasks', icon: Calendar, label: 'Tasks' },
    { path: '/statistics', icon: BarChart3, label: 'Stats' },
    { path: '/profile', icon: User, label: 'Profile' },
  ];

  return (
    <div className="min-h-screen bg-[#F5F7FA] pb-20">
      {/* Main Content */}
      <main className="min-h-screen">
        <Outlet />
      </main>

      {/* Floating Add Button */}
      <Link to="/add-task">
        <Button
          className="fixed bottom-24 right-6 w-14 h-14 bg-[#FFD60A] hover:bg-[#FFC800] text-[#1E1E1E] rounded-full shadow-2xl transition-all duration-200 transform hover:scale-110 active:scale-95 z-50"
        >
          <Plus className="w-6 h-6" />
        </Button>
      </Link>

      {/* Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-[#E5E7EB] z-40">
        <div className="max-w-screen-xl mx-auto px-4">
          <div className="flex items-center justify-around h-20">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className="flex flex-col items-center justify-center gap-1 min-w-[70px] group"
                >
                  <div className={`p-2 rounded-xl transition-all duration-200 ${
                    isActive 
                      ? 'bg-[#007AFF]' 
                      : 'group-hover:bg-[#F5F7FA]'
                  }`}>
                    <Icon className={`w-6 h-6 transition-colors ${
                      isActive 
                        ? 'text-white' 
                        : 'text-[#6B7280] group-hover:text-[#007AFF]'
                    }`} />
                  </div>
                  <span className={`text-xs transition-colors ${
                    isActive 
                      ? 'text-[#007AFF]' 
                      : 'text-[#6B7280] group-hover:text-[#007AFF]'
                  }`}>
                    {item.label}
                  </span>
                </Link>
              );
            })}
          </div>
        </div>
      </nav>
    </div>
  );
}
