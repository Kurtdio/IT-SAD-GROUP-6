import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Search, Filter, Calendar as CalendarIcon, List, Edit2, Trash2 } from 'lucide-react';
import { motion } from 'motion/react';

export default function TasksList() {
  const [viewMode, setViewMode] = useState<'list' | 'calendar'>('list');
  const [searchQuery, setSearchQuery] = useState('');

  const tasks = [
    { id: 1, title: 'Math Assignment', course: 'Calculus II', due: 'Nov 11, 2025', dueTime: '11:59 PM', priority: 'high', status: 'todo', category: 'Assignment' },
    { id: 2, title: 'Biology Lab Report', course: 'Biology 101', due: 'Nov 12, 2025', dueTime: '5:00 PM', priority: 'medium', status: 'todo', category: 'Lab' },
    { id: 3, title: 'Read Chapter 5', course: 'English Literature', due: 'Nov 13, 2025', dueTime: '9:00 AM', priority: 'low', status: 'completed', category: 'Reading' },
    { id: 4, title: 'Study for Physics Exam', course: 'Physics', due: 'Nov 18, 2025', dueTime: '2:00 PM', priority: 'high', status: 'todo', category: 'Exam' },
    { id: 5, title: 'Group Project Meeting', course: 'Computer Science', due: 'Nov 14, 2025', dueTime: '3:00 PM', priority: 'medium', status: 'in-progress', category: 'Project' },
    { id: 6, title: 'Essay Outline', course: 'History', due: 'Nov 15, 2025', dueTime: '11:59 PM', priority: 'medium', status: 'todo', category: 'Essay' },
  ];

  const todoTasks = tasks.filter(t => t.status === 'todo');
  const inProgressTasks = tasks.filter(t => t.status === 'in-progress');
  const completedTasks = tasks.filter(t => t.status === 'completed');

  const TaskCard = ({ task }: { task: typeof tasks[0] }) => (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="p-4 bg-white rounded-2xl shadow-sm border-0 hover:shadow-md transition-all">
        <div className="flex items-start gap-3">
          <button className="mt-1 w-5 h-5 rounded-full border-2 border-[#007AFF] hover:bg-[#007AFF] transition-colors flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <h4 className="text-[#1E1E1E] mb-1">{task.title}</h4>
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <span className="text-sm text-[#6B7280]">{task.course}</span>
              <span className="w-1 h-1 bg-[#6B7280] rounded-full" />
              <span className="text-sm text-[#6B7280]">{task.category}</span>
            </div>
            <div className="flex items-center gap-2">
              <CalendarIcon className="w-4 h-4 text-[#6B7280]" />
              <span className="text-sm text-[#6B7280]">{task.due} at {task.dueTime}</span>
            </div>
          </div>
          <div className="flex flex-col items-end gap-2">
            <div className={`px-3 py-1 rounded-full text-xs ${
              task.priority === 'high' ? 'bg-[#FF3B30]/10 text-[#FF3B30]' :
              task.priority === 'medium' ? 'bg-[#FF9500]/10 text-[#FF9500]' :
              'bg-[#34C759]/10 text-[#34C759]'
            }`}>
              {task.priority}
            </div>
            <div className="flex gap-1">
              <Link to={`/edit-task/${task.id}`}>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0 hover:bg-[#007AFF]/10 rounded-lg">
                  <Edit2 className="w-4 h-4 text-[#007AFF]" />
                </Button>
              </Link>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0 hover:bg-[#FF3B30]/10 rounded-lg">
                <Trash2 className="w-4 h-4 text-[#FF3B30]" />
              </Button>
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      {/* Header */}
      <div className="bg-white pt-12 pb-6 px-4 border-b border-[#E5E7EB]">
        <div className="max-w-screen-xl mx-auto">
          <h1 className="text-[#1E1E1E] mb-6">My Tasks</h1>
          
          {/* Search and Filter */}
          <div className="flex gap-3 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
              <Input
                placeholder="Search tasks..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 h-12 rounded-xl border-2 border-[#E5E7EB] focus:border-[#007AFF]"
              />
            </div>
            <Button variant="outline" className="h-12 px-4 rounded-xl border-2 border-[#E5E7EB] hover:border-[#007AFF] hover:bg-[#007AFF]/5">
              <Filter className="w-5 h-5" />
            </Button>
          </div>

          {/* View Toggle */}
          <div className="flex gap-2">
            <Button
              variant={viewMode === 'list' ? 'default' : 'outline'}
              onClick={() => setViewMode('list')}
              className={`h-10 px-4 rounded-xl ${
                viewMode === 'list' 
                  ? 'bg-[#007AFF] text-white' 
                  : 'border-2 border-[#E5E7EB] hover:border-[#007AFF]'
              }`}
            >
              <List className="w-4 h-4 mr-2" />
              List
            </Button>
            <Button
              variant={viewMode === 'calendar' ? 'default' : 'outline'}
              onClick={() => setViewMode('calendar')}
              className={`h-10 px-4 rounded-xl ${
                viewMode === 'calendar' 
                  ? 'bg-[#007AFF] text-white' 
                  : 'border-2 border-[#E5E7EB] hover:border-[#007AFF]'
              }`}
            >
              <CalendarIcon className="w-4 h-4 mr-2" />
              Calendar
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-screen-xl mx-auto px-4 py-6">
        {viewMode === 'list' ? (
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="w-full grid grid-cols-4 h-12 bg-white rounded-xl p-1 mb-6">
              <TabsTrigger value="all" className="rounded-lg data-[state=active]:bg-[#007AFF] data-[state=active]:text-white">
                All ({tasks.length})
              </TabsTrigger>
              <TabsTrigger value="todo" className="rounded-lg data-[state=active]:bg-[#007AFF] data-[state=active]:text-white">
                To Do ({todoTasks.length})
              </TabsTrigger>
              <TabsTrigger value="progress" className="rounded-lg data-[state=active]:bg-[#007AFF] data-[state=active]:text-white">
                In Progress ({inProgressTasks.length})
              </TabsTrigger>
              <TabsTrigger value="completed" className="rounded-lg data-[state=active]:bg-[#007AFF] data-[state=active]:text-white">
                Done ({completedTasks.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-3">
              {tasks.map((task) => (
                <TaskCard key={task.id} task={task} />
              ))}
            </TabsContent>

            <TabsContent value="todo" className="space-y-3">
              {todoTasks.map((task) => (
                <TaskCard key={task.id} task={task} />
              ))}
            </TabsContent>

            <TabsContent value="progress" className="space-y-3">
              {inProgressTasks.map((task) => (
                <TaskCard key={task.id} task={task} />
              ))}
            </TabsContent>

            <TabsContent value="completed" className="space-y-3">
              {completedTasks.map((task) => (
                <TaskCard key={task.id} task={task} />
              ))}
            </TabsContent>
          </Tabs>
        ) : (
          <Card className="p-6 bg-white rounded-2xl border-0">
            <div className="text-center py-12">
              <CalendarIcon className="w-16 h-16 text-[#6B7280] mx-auto mb-4" />
              <h3 className="text-[#1E1E1E] mb-2">Calendar View</h3>
              <p className="text-[#6B7280]">Visual calendar view coming soon!</p>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
