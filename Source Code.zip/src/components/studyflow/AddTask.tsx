import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { ArrowLeft, Calendar as CalendarIcon, Clock, Flag } from 'lucide-react';
import { motion } from 'motion/react';

export default function AddTask() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEditing = !!id;

  const [title, setTitle] = useState('');
  const [course, setCourse] = useState('');
  const [category, setCategory] = useState('Assignment');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [dueTime, setDueTime] = useState('');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');

  const categories = ['Assignment', 'Exam', 'Project', 'Lab', 'Reading', 'Essay', 'Other'];
  const priorities: Array<{ value: 'low' | 'medium' | 'high'; label: string; color: string }> = [
    { value: 'low', label: 'Low', color: 'bg-[#34C759]' },
    { value: 'medium', label: 'Medium', color: 'bg-[#FF9500]' },
    { value: 'high', label: 'High', color: 'bg-[#FF3B30]' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle save logic here
    navigate('/tasks');
  };

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      {/* Header */}
      <div className="bg-white pt-12 pb-6 px-4 border-b border-[#E5E7EB]">
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <Button
              variant="ghost"
              onClick={() => navigate(-1)}
              className="w-10 h-10 p-0 rounded-xl hover:bg-[#F5F7FA]"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <h1 className="text-[#1E1E1E]">{isEditing ? 'Edit Task' : 'Add New Task'}</h1>
          </div>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="max-w-screen-xl mx-auto px-4 py-6"
      >
        <Card className="p-6 bg-white rounded-2xl border-0 shadow-sm">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Title */}
            <div>
              <Label htmlFor="title" className="text-[#1E1E1E] mb-2">Task Title *</Label>
              <Input
                id="title"
                placeholder="e.g., Complete Math Assignment"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="h-12 rounded-xl border-2 border-[#E5E7EB] focus:border-[#007AFF]"
                required
              />
            </div>

            {/* Course */}
            <div>
              <Label htmlFor="course" className="text-[#1E1E1E] mb-2">Course/Subject *</Label>
              <Input
                id="course"
                placeholder="e.g., Calculus II"
                value={course}
                onChange={(e) => setCourse(e.target.value)}
                className="h-12 rounded-xl border-2 border-[#E5E7EB] focus:border-[#007AFF]"
                required
              />
            </div>

            {/* Category */}
            <div>
              <Label className="text-[#1E1E1E] mb-2">Category</Label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setCategory(cat)}
                    className={`py-2 px-4 rounded-xl border-2 transition-all ${
                      category === cat
                        ? 'border-[#007AFF] bg-[#007AFF]/10 text-[#007AFF]'
                        : 'border-[#E5E7EB] hover:border-[#007AFF]/50'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Description */}
            <div>
              <Label htmlFor="description" className="text-[#1E1E1E] mb-2">Description</Label>
              <Textarea
                id="description"
                placeholder="Add notes or details about this task..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="min-h-[120px] rounded-xl border-2 border-[#E5E7EB] focus:border-[#007AFF]"
              />
            </div>

            {/* Due Date and Time */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="dueDate" className="text-[#1E1E1E] mb-2 flex items-center gap-2">
                  <CalendarIcon className="w-4 h-4" />
                  Due Date *
                </Label>
                <Input
                  id="dueDate"
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="h-12 rounded-xl border-2 border-[#E5E7EB] focus:border-[#007AFF]"
                  required
                />
              </div>
              <div>
                <Label htmlFor="dueTime" className="text-[#1E1E1E] mb-2 flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Due Time *
                </Label>
                <Input
                  id="dueTime"
                  type="time"
                  value={dueTime}
                  onChange={(e) => setDueTime(e.target.value)}
                  className="h-12 rounded-xl border-2 border-[#E5E7EB] focus:border-[#007AFF]"
                  required
                />
              </div>
            </div>

            {/* Priority */}
            <div>
              <Label className="text-[#1E1E1E] mb-2 flex items-center gap-2">
                <Flag className="w-4 h-4" />
                Priority
              </Label>
              <div className="grid grid-cols-3 gap-3 mt-2">
                {priorities.map((p) => (
                  <button
                    key={p.value}
                    type="button"
                    onClick={() => setPriority(p.value)}
                    className={`py-3 rounded-xl border-2 transition-all ${
                      priority === p.value
                        ? `border-transparent ${p.color} text-white`
                        : 'border-[#E5E7EB] hover:border-[#E5E7EB]/50'
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Buttons */}
            <div className="flex gap-3 pt-4">
              <Button
                type="submit"
                className="flex-1 h-12 bg-[#007AFF] hover:bg-[#0051D5] text-white rounded-xl transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98]"
              >
                {isEditing ? 'Update Task' : 'Create Task'}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate(-1)}
                className="flex-1 h-12 border-2 border-[#E5E7EB] hover:border-[#007AFF] rounded-xl"
              >
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      </motion.div>
    </div>
  );
}
