import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { ArrowLeft, GraduationCap, Mail, MessageCircle, ExternalLink, Heart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';

export default function About() {
  const navigate = useNavigate();

  const features = [
    'Task and assignment tracking',
    'Calendar and deadline management',
    'Priority setting and categorization',
    'Progress tracking and statistics',
    'Smart notifications and reminders',
    'Clean and intuitive interface'
  ];

  const supportOptions = [
    {
      icon: Mail,
      title: 'Email Support',
      description: 'support@studyflow.com',
      action: 'mailto:support@studyflow.com'
    },
    {
      icon: MessageCircle,
      title: 'Live Chat',
      description: 'Chat with our team',
      action: '#'
    },
    {
      icon: ExternalLink,
      title: 'Documentation',
      description: 'View user guides',
      action: '#'
    }
  ];

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      {/* Header */}
      <div className="bg-white pt-12 pb-6 px-4 border-b border-[#E5E7EB]">
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              onClick={() => navigate(-1)}
              className="w-10 h-10 p-0 rounded-xl hover:bg-[#F5F7FA]"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <h1 className="text-[#1E1E1E]">About & Help</h1>
          </div>
        </div>
      </div>

      <div className="max-w-screen-xl mx-auto px-4 py-6 space-y-6">
        {/* App Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="p-8 bg-gradient-to-br from-[#007AFF] to-[#0051D5] rounded-2xl border-0 shadow-lg text-white text-center">
            <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center mx-auto mb-4">
              <GraduationCap className="w-12 h-12 text-[#007AFF]" />
            </div>
            <h2 className="text-white mb-2">StudyFlow</h2>
            <p className="text-white/80 mb-1">Version 1.0.0</p>
            <p className="text-white/80">Your Study Companion</p>
          </Card>
        </motion.div>

        {/* About StudyFlow */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
        >
          <Card className="p-6 bg-white rounded-2xl border-0 shadow-sm">
            <h3 className="text-[#1E1E1E] mb-3">About StudyFlow</h3>
            <p className="text-[#6B7280] mb-4">
              StudyFlow is a productivity app designed specifically for students to help manage 
              their tasks, assignments, and deadlines. Built with simplicity and efficiency in mind, 
              StudyFlow helps you stay organized and focused on what matters most - your education.
            </p>
            <div className="space-y-2">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-[#007AFF] rounded-full" />
                  <span className="text-[#1E1E1E]">{feature}</span>
                </div>
              ))}
            </div>
          </Card>
        </motion.div>

        {/* Support Options */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
        >
          <h3 className="text-[#1E1E1E] mb-3">Get Help</h3>
          <div className="space-y-3">
            {supportOptions.map((option, index) => {
              const Icon = option.icon;
              return (
                <a key={index} href={option.action}>
                  <Card className="p-4 bg-white rounded-2xl border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-[#007AFF]/10 rounded-xl flex items-center justify-center">
                        <Icon className="w-6 h-6 text-[#007AFF]" />
                      </div>
                      <div className="flex-1">
                        <h4 className="text-[#1E1E1E] mb-1">{option.title}</h4>
                        <p className="text-sm text-[#6B7280]">{option.description}</p>
                      </div>
                      <div className="text-[#6B7280]">›</div>
                    </div>
                  </Card>
                </a>
              );
            })}
          </div>
        </motion.div>

        {/* FAQs Preview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.3 }}
        >
          <Card className="p-6 bg-white rounded-2xl border-0 shadow-sm">
            <h3 className="text-[#1E1E1E] mb-4">Common Questions</h3>
            <div className="space-y-4">
              <div>
                <h4 className="text-[#1E1E1E] mb-2">How do I add a new task?</h4>
                <p className="text-sm text-[#6B7280]">
                  Tap the yellow "+" button at the bottom right of the screen to add a new task.
                </p>
              </div>
              <div>
                <h4 className="text-[#1E1E1E] mb-2">Can I set reminders for tasks?</h4>
                <p className="text-sm text-[#6B7280]">
                  Yes! When creating a task, set a due date and time. You'll receive notifications 
                  before the deadline.
                </p>
              </div>
              <div>
                <h4 className="text-[#1E1E1E] mb-2">How do I mark a task as complete?</h4>
                <p className="text-sm text-[#6B7280]">
                  Tap the circle next to any task to mark it as complete. You can view all completed 
                  tasks in the "Done" tab.
                </p>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Footer */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.4 }}
        >
          <Card className="p-6 bg-white rounded-2xl border-0 shadow-sm text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <span className="text-[#1E1E1E]">Made with</span>
              <Heart className="w-5 h-5 text-[#FF3B30] fill-current" />
              <span className="text-[#1E1E1E]">for students</span>
            </div>
            <p className="text-sm text-[#6B7280]">© 2025 StudyFlow. All rights reserved.</p>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
