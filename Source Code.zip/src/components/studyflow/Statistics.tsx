import { Card } from '../ui/card';
import { TrendingUp, Target, Award, Calendar } from 'lucide-react';
import { motion } from 'motion/react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

export default function Statistics() {
  const stats = [
    { label: 'Total Tasks', value: '127', icon: Target, color: 'bg-[#007AFF]' },
    { label: 'Completed', value: '89', icon: Award, color: 'bg-[#34C759]' },
    { label: 'Success Rate', value: '85%', icon: TrendingUp, color: 'bg-[#FFD60A]' },
    { label: 'Current Streak', value: '7 days', icon: Calendar, color: 'bg-[#FF9500]' },
  ];

  const weeklyData = [
    { day: 'Mon', completed: 8, pending: 3 },
    { day: 'Tue', completed: 12, pending: 5 },
    { day: 'Wed', completed: 10, pending: 4 },
    { day: 'Thu', completed: 15, pending: 2 },
    { day: 'Fri', completed: 14, pending: 6 },
    { day: 'Sat', completed: 7, pending: 2 },
    { day: 'Sun', completed: 5, pending: 1 }
  ];

  const categoryData = [
    { name: 'Assignments', value: 35, color: '#007AFF' },
    { name: 'Exams', value: 20, color: '#FF3B30' },
    { name: 'Projects', value: 25, color: '#34C759' },
    { name: 'Reading', value: 15, color: '#FF9500' },
    { name: 'Other', value: 5, color: '#FFD60A' }
  ];

  const monthlyTrend = [
    { month: 'Jul', completed: 45 },
    { month: 'Aug', completed: 52 },
    { month: 'Sep', completed: 48 },
    { month: 'Oct', completed: 61 },
    { month: 'Nov', completed: 72 }
  ];

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#007AFF] to-[#0051D5] pt-12 pb-24 px-4 rounded-b-[32px]">
        <div className="max-w-screen-xl mx-auto">
          <h1 className="text-white mb-2">Statistics</h1>
          <p className="text-white/80">Track your progress and productivity</p>
        </div>
      </div>

      <div className="max-w-screen-xl mx-auto px-4 -mt-16">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Card className="p-4 bg-white rounded-2xl shadow-lg border-0">
                  <div className={`w-10 h-10 ${stat.color} rounded-xl flex items-center justify-center mb-3`}>
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <div className="text-2xl text-[#1E1E1E] mb-1">{stat.value}</div>
                  <div className="text-sm text-[#6B7280]">{stat.label}</div>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Weekly Activity */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.4 }}
          className="mb-6"
        >
          <Card className="p-6 bg-white rounded-2xl border-0 shadow-sm">
            <h3 className="text-[#1E1E1E] mb-4">Weekly Activity</h3>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis dataKey="day" stroke="#6B7280" />
                <YAxis stroke="#6B7280" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#fff', 
                    border: '1px solid #E5E7EB',
                    borderRadius: '12px'
                  }} 
                />
                <Bar dataKey="completed" fill="#007AFF" radius={[8, 8, 0, 0]} />
                <Bar dataKey="pending" fill="#FFD60A" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </motion.div>

        {/* Category Distribution & Monthly Trend */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.5 }}
          >
            <Card className="p-6 bg-white rounded-2xl border-0 shadow-sm">
              <h3 className="text-[#1E1E1E] mb-4">Task Categories</h3>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.6 }}
          >
            <Card className="p-6 bg-white rounded-2xl border-0 shadow-sm">
              <h3 className="text-[#1E1E1E] mb-4">Monthly Progress</h3>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={monthlyTrend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                  <XAxis dataKey="month" stroke="#6B7280" />
                  <YAxis stroke="#6B7280" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#fff', 
                      border: '1px solid #E5E7EB',
                      borderRadius: '12px'
                    }} 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="completed" 
                    stroke="#007AFF" 
                    strokeWidth={3}
                    dot={{ fill: '#007AFF', r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </Card>
          </motion.div>
        </div>

        {/* Productivity Insights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.7 }}
          className="mb-6"
        >
          <Card className="p-6 bg-gradient-to-br from-[#34C759] to-[#30D158] rounded-2xl border-0 shadow-lg text-white">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-white mb-2">Great Progress! 🎉</h3>
                <p className="text-white/90 mb-1">You've completed 89 tasks this month</p>
                <p className="text-white/90">That's 15% more than last month!</p>
              </div>
              <TrendingUp className="w-16 h-16 text-white/30" />
            </div>
          </Card>
        </motion.div>

        {/* Best Performance Day */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.8 }}
        >
          <Card className="p-6 bg-white rounded-2xl border-0 shadow-sm">
            <h3 className="text-[#1E1E1E] mb-4">Insights</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-[#007AFF] rounded-full mt-2" />
                <div>
                  <p className="text-[#1E1E1E] mb-1">Most Productive Day</p>
                  <p className="text-sm text-[#6B7280]">Thursday - You complete an average of 15 tasks</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-[#34C759] rounded-full mt-2" />
                <div>
                  <p className="text-[#1E1E1E] mb-1">Completion Rate</p>
                  <p className="text-sm text-[#6B7280]">You complete 85% of your tasks on time</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-[#FFD60A] rounded-full mt-2" />
                <div>
                  <p className="text-[#1E1E1E] mb-1">Focus Area</p>
                  <p className="text-sm text-[#6B7280]">Most of your tasks are Assignments (35%)</p>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
