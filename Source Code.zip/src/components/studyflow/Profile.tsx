import { Link, useNavigate } from 'react-router-dom';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Mail, School, Calendar, Settings, HelpCircle, LogOut, Edit2, Award, Target, TrendingUp } from 'lucide-react';
import { motion } from 'motion/react';

interface ProfileProps {
  setIsAuthenticated?: (value: boolean) => void;
}

export default function Profile({ setIsAuthenticated }: ProfileProps) {
  const navigate = useNavigate();

  const handleLogout = () => {
    if (setIsAuthenticated) {
      setIsAuthenticated(false);
    }
    navigate('/login');
  };

  const achievements = [
    { icon: Award, label: 'Top Performer', description: 'Completed 50 tasks', color: 'bg-[#FFD60A]' },
    { icon: Target, label: 'On Track', description: '7 day streak', color: 'bg-[#007AFF]' },
    { icon: TrendingUp, label: 'Productivity Pro', description: '85% completion rate', color: 'bg-[#34C759]' },
  ];

  const stats = [
    { label: 'Total Tasks', value: '127' },
    { label: 'Completed', value: '89' },
    { label: 'In Progress', value: '14' },
    { label: 'Success Rate', value: '85%' },
  ];

  const menuItems = [
    { icon: Settings, label: 'Settings', path: '/settings', color: 'text-[#007AFF]' },
    { icon: HelpCircle, label: 'Help & About', path: '/about', color: 'text-[#007AFF]' },
    { icon: LogOut, label: 'Logout', action: handleLogout, color: 'text-[#FF3B30]' },
  ];

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      {/* Header with Profile Info */}
      <div className="bg-gradient-to-br from-[#007AFF] to-[#0051D5] pt-12 pb-32 px-4 rounded-b-[32px]">
        <div className="max-w-screen-xl mx-auto">
          <div className="text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              <Avatar className="w-24 h-24 mx-auto mb-4 border-4 border-white/20">
                <AvatarFallback className="bg-white text-[#007AFF] text-2xl">
                  SD
                </AvatarFallback>
              </Avatar>
            </motion.div>
            <h1 className="text-white mb-2">Student Name</h1>
            <p className="text-white/80 mb-4">Computer Science Major</p>
            <Button className="bg-white/20 hover:bg-white/30 text-white backdrop-blur-sm rounded-xl h-10 px-6">
              <Edit2 className="w-4 h-4 mr-2" />
              Edit Profile
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-screen-xl mx-auto px-4 -mt-20">
        {/* Contact Info Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="mb-6"
        >
          <Card className="p-6 bg-white rounded-2xl border-0 shadow-lg">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#007AFF]/10 rounded-xl flex items-center justify-center">
                  <Mail className="w-5 h-5 text-[#007AFF]" />
                </div>
                <div>
                  <div className="text-sm text-[#6B7280]">Email</div>
                  <div className="text-[#1E1E1E]">student@university.edu</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#007AFF]/10 rounded-xl flex items-center justify-center">
                  <School className="w-5 h-5 text-[#007AFF]" />
                </div>
                <div>
                  <div className="text-sm text-[#6B7280]">School</div>
                  <div className="text-[#1E1E1E]">State University</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#007AFF]/10 rounded-xl flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-[#007AFF]" />
                </div>
                <div>
                  <div className="text-sm text-[#6B7280]">Member Since</div>
                  <div className="text-[#1E1E1E]">January 2024</div>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          className="mb-6"
        >
          <h3 className="text-[#1E1E1E] mb-3">Your Statistics</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {stats.map((stat, index) => (
              <Card key={index} className="p-4 bg-white rounded-2xl border-0 shadow-sm text-center">
                <div className="text-2xl text-[#007AFF] mb-1">{stat.value}</div>
                <div className="text-sm text-[#6B7280]">{stat.label}</div>
              </Card>
            ))}
          </div>
        </motion.div>

        {/* Achievements */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
          className="mb-6"
        >
          <h3 className="text-[#1E1E1E] mb-3">Achievements</h3>
          <div className="space-y-3">
            {achievements.map((achievement, index) => {
              const Icon = achievement.icon;
              return (
                <Card key={index} className="p-4 bg-white rounded-2xl border-0 shadow-sm">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 ${achievement.color} rounded-xl flex items-center justify-center`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-[#1E1E1E] mb-1">{achievement.label}</h4>
                      <p className="text-sm text-[#6B7280]">{achievement.description}</p>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </motion.div>

        {/* Menu Items */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.3 }}
          className="space-y-3 pb-6"
        >
          {menuItems.map((item, index) => {
            const Icon = item.icon;
            const content = (
              <Card className="p-4 bg-white rounded-2xl border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Icon className={`w-5 h-5 ${item.color}`} />
                    <span className={`${item.color}`}>{item.label}</span>
                  </div>
                  <div className="text-[#6B7280]">›</div>
                </div>
              </Card>
            );

            if (item.path) {
              return (
                <Link key={index} to={item.path}>
                  {content}
                </Link>
              );
            } else if (item.action) {
              return (
                <button key={index} onClick={item.action} className="w-full">
                  {content}
                </button>
              );
            }
          })}
        </motion.div>
      </div>
    </div>
  );
}
