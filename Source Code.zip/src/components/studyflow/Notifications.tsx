import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { ArrowLeft, Bell, CheckCircle2, AlertCircle, Calendar, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';

export default function Notifications() {
  const navigate = useNavigate();

  const notifications = [
    {
      id: 1,
      type: 'deadline',
      icon: AlertCircle,
      title: 'Math Assignment Due Soon',
      message: 'Your Calculus II assignment is due today at 11:59 PM',
      time: '2 hours ago',
      read: false,
      color: 'bg-[#FF3B30]'
    },
    {
      id: 2,
      type: 'reminder',
      icon: Bell,
      title: 'Study Reminder',
      message: 'Time to review Physics notes for upcoming exam',
      time: '4 hours ago',
      read: false,
      color: 'bg-[#007AFF]'
    },
    {
      id: 3,
      type: 'completed',
      icon: CheckCircle2,
      title: 'Task Completed',
      message: 'You completed "Biology Lab Report". Great job!',
      time: '1 day ago',
      read: true,
      color: 'bg-[#34C759]'
    },
    {
      id: 4,
      type: 'upcoming',
      icon: Calendar,
      title: 'Upcoming Exam',
      message: 'Physics exam is scheduled for Nov 18 at 2:00 PM',
      time: '2 days ago',
      read: true,
      color: 'bg-[#FF9500]'
    },
    {
      id: 5,
      type: 'reminder',
      icon: Bell,
      title: 'Daily Summary',
      message: 'You have 3 tasks due today and 5 pending tasks',
      time: '3 days ago',
      read: true,
      color: 'bg-[#007AFF]'
    }
  ];

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      {/* Header */}
      <div className="bg-white pt-12 pb-6 px-4 border-b border-[#E5E7EB]">
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                onClick={() => navigate(-1)}
                className="w-10 h-10 p-0 rounded-xl hover:bg-[#F5F7FA]"
              >
                <ArrowLeft className="w-6 h-6" />
              </Button>
              <div>
                <h1 className="text-[#1E1E1E]">Notifications</h1>
                {unreadCount > 0 && (
                  <p className="text-sm text-[#6B7280]">{unreadCount} unread</p>
                )}
              </div>
            </div>
            <Button 
              variant="ghost" 
              className="text-[#007AFF] hover:bg-[#007AFF]/10 rounded-xl"
            >
              Mark all read
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-screen-xl mx-auto px-4 py-6">
        {notifications.length > 0 ? (
          <div className="space-y-3">
            {notifications.map((notification, index) => {
              const Icon = notification.icon;
              return (
                <motion.div
                  key={notification.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                >
                  <Card className={`p-4 rounded-2xl border-0 shadow-sm hover:shadow-md transition-shadow ${
                    !notification.read ? 'bg-[#007AFF]/5 border-l-4 border-l-[#007AFF]' : 'bg-white'
                  }`}>
                    <div className="flex items-start gap-3">
                      <div className={`w-10 h-10 ${notification.color} rounded-xl flex items-center justify-center flex-shrink-0`}>
                        <Icon className="w-5 h-5 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2 mb-1">
                          <h4 className="text-[#1E1E1E]">
                            {notification.title}
                            {!notification.read && (
                              <span className="ml-2 inline-block w-2 h-2 bg-[#007AFF] rounded-full" />
                            )}
                          </h4>
                          <span className="text-sm text-[#6B7280] whitespace-nowrap">{notification.time}</span>
                        </div>
                        <p className="text-sm text-[#6B7280] mb-3">{notification.message}</p>
                        <div className="flex gap-2">
                          {!notification.read && (
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-8 px-3 text-[#007AFF] hover:bg-[#007AFF]/10 rounded-lg"
                            >
                              Mark as read
                            </Button>
                          )}
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0 hover:bg-[#FF3B30]/10 rounded-lg"
                          >
                            <Trash2 className="w-4 h-4 text-[#FF3B30]" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="p-12 bg-white rounded-2xl border-0 shadow-sm text-center">
              <div className="w-16 h-16 bg-[#F5F7FA] rounded-full flex items-center justify-center mx-auto mb-4">
                <Bell className="w-8 h-8 text-[#6B7280]" />
              </div>
              <h3 className="text-[#1E1E1E] mb-2">No notifications</h3>
              <p className="text-[#6B7280]">You're all caught up! We'll notify you when something new happens.</p>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
}
