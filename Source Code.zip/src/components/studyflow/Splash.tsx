import { motion } from 'motion/react';
import { GraduationCap } from 'lucide-react';

export default function Splash() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#007AFF] to-[#0051D5] flex items-center justify-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="text-center"
      >
        <motion.div
          animate={{ 
            scale: [1, 1.1, 1],
          }}
          transition={{ 
            duration: 1.5, 
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="w-24 h-24 bg-white rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-2xl"
        >
          <GraduationCap className="w-14 h-14 text-[#007AFF]" />
        </motion.div>
        
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-white text-5xl mb-3"
        >
          StudyFlow
        </motion.h1>
        
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-white/90 text-lg"
        >
          Your Study Companion
        </motion.p>
      </motion.div>
    </div>
  );
}
