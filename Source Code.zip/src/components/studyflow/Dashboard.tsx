import { Link } from 'react-router-dom';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Bell, Settings, CheckCircle2, Clock, AlertCircle, TrendingUp } from 'lucide-react';
import { motion } from 'motion/react';

export default function Dashboard() {
  const upcomingTasks = [
    { id: 1, title: 'Math Assignment', course: 'Calculus II', due: 'Today, 11:59 PM', priority: 'high', completed: false },
    { id: 2, title: 'Biology Lab Report', course: 'Biology 101', due: 'Tomorrow, 5:00 PM', priority: 'medium', completed: false },
    { id: 3, title: 'Essay Draft', course: 'English Literature', due: 'Nov 15, 2025', priority: 'low', completed: false },
    { id: 4, title: 'Study for Physics Exam', course: 'Physics', due: 'Nov 18, 2025', priority: 'high', completed: false },
  ];

  const stats = [
    { label: 'Tasks Due Today', value: '3', icon: Clock, color: 'bg-[#007AFF]' },
    { label: 'Completed This Week', value: '12', icon: CheckCircle2, color: 'bg-[#34C759]' },
    { label: 'Overdue', value: '1', icon: AlertCircle, color: 'bg-[#FF3B30]' },
  ];

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#007AFF] to-[#0051D5] pt-12 pb-24 px-4 rounded-b-[32px]">
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-white mb-1">Hello, Student! 👋</h1>
              <p className="text-white/80">Let's make today productive</p>
            </div>
            <div className="flex gap-2">
              <Link to="/notifications">
                <Button 
                  variant="ghost" 
                  size="icon"
                  className="w-10 h-10 bg-white/20 hover:bg-white/30 text-white rounded-xl backdrop-blur-sm"
                >
                  <Bell className="w-5 h-5" />
                </Button>
              </Link>
              <Link to="/settings">
                <Button 
                  variant="ghost" 
                  size="icon"
                  className="w-10 h-10 bg-white/20 hover:bg-white/30 text-white rounded-xl backdrop-blur-sm"
                >
                  <Settings className="w-5 h-5" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-screen-xl mx-auto px-4 -mt-16">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Card className="p-4 bg-white rounded-2xl shadow-lg border-0">
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 ${stat.color} rounded-xl flex items-center justify-center`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="text-2xl text-[#1E1E1E]">{stat.value}</div>
                      <div className="text-sm text-[#6B7280]">{stat.label}</div>
                    </div>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.3 }}
          className="mb-6"
        >
          <Card className="p-6 bg-gradient-to-br from-[#FFD60A] to-[#FFC800] rounded-2xl border-0 shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-[#1E1E1E] mb-1">Keep the momentum going!</h3>
                <p className="text-[#1E1E1E]/70">You've completed 85% of your weekly goals</p>
              </div>
              <TrendingUp className="w-12 h-12 text-[#1E1E1E]/50" />
            </div>
          </Card>
        </motion.div>

        {/* Upcoming Tasks */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.4 }}
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-[#1E1E1E]">Upcoming Tasks</h2>
            <Link to="/tasks">
              <Button variant="ghost" className="text-[#007AFF] hover:bg-[#007AFF]/10 rounded-xl">
                View All
              </Button>
            </Link>
          </div>

          <div className="space-y-3">
            {upcomingTasks.map((task, index) => (
              <motion.div
                key={task.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: 0.5 + index * 0.1 }}
              >
                <Card className="p-4 bg-white rounded-2xl shadow-sm border-0 hover:shadow-md transition-shadow">
                  <div className="flex items-start gap-3">
                    <button className="mt-1 w-5 h-5 rounded-full border-2 border-[#007AFF] hover:bg-[#007AFF] transition-colors flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-[#1E1E1E] mb-1">{task.title}</h4>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm text-[#6B7280]">{task.course}</span>
                        <span className="w-1 h-1 bg-[#6B7280] rounded-full" />
                        <span className="text-sm text-[#6B7280]">{task.due}</span>
                      </div>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-xs ${
                      task.priority === 'high' ? 'bg-[#FF3B30]/10 text-[#FF3B30]' :
                      task.priority === 'medium' ? 'bg-[#FF9500]/10 text-[#FF9500]' :
                      'bg-[#34C759]/10 text-[#34C759]'
                    }`}>
                      {task.priority}
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
