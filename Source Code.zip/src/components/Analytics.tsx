import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { TrendingUp, Target, Activity, Award } from 'lucide-react';
import { motion } from 'motion/react';
import { 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend
} from 'recharts';

export default function Analytics() {
  const metrics = [
    {
      title: 'Productivity Score',
      value: '87%',
      change: '+5%',
      icon: Activity,
      color: 'from-blue-600 to-indigo-600'
    },
    {
      title: 'Tasks Completed',
      value: '342',
      change: '+12%',
      icon: Target,
      color: 'from-green-600 to-emerald-600'
    },
    {
      title: 'Success Rate',
      value: '94%',
      change: '+3%',
      icon: Award,
      color: 'from-purple-600 to-pink-600'
    },
    {
      title: 'Avg. Completion',
      value: '3.2 days',
      change: '-0.5d',
      icon: TrendingUp,
      color: 'from-amber-600 to-orange-600'
    }
  ];

  const weeklyData = [
    { day: 'Mon', completed: 45, pending: 12 },
    { day: 'Tue', completed: 52, pending: 18 },
    { day: 'Wed', completed: 48, pending: 15 },
    { day: 'Thu', completed: 61, pending: 10 },
    { day: 'Fri', completed: 55, pending: 14 },
    { day: 'Sat', completed: 28, pending: 8 },
    { day: 'Sun', completed: 22, pending: 5 }
  ];

  const monthlyTrend = [
    { month: 'Jan', value: 420 },
    { month: 'Feb', value: 380 },
    { month: 'Mar', value: 450 },
    { month: 'Apr', value: 520 },
    { month: 'May', value: 580 },
    { month: 'Jun', value: 640 }
  ];

  const projectDistribution = [
    { name: 'Development', value: 35, color: '#3b82f6' },
    { name: 'Design', value: 25, color: '#8b5cf6' },
    { name: 'Marketing', value: 20, color: '#f59e0b' },
    { name: 'Testing', value: 15, color: '#10b981' },
    { name: 'Other', value: 5, color: '#64748b' }
  ];

  const teamPerformance = [
    { name: 'John Doe', tasks: 42, efficiency: 92 },
    { name: 'Jane Smith', tasks: 38, efficiency: 88 },
    { name: 'Mike Johnson', tasks: 35, efficiency: 85 },
    { name: 'Sarah Williams', tasks: 31, efficiency: 90 },
    { name: 'Tom Brown', tasks: 28, efficiency: 87 }
  ];

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-slate-900 mb-2">Analytics</h1>
          <p className="text-slate-600">Track your performance and insights</p>
        </div>

        {/* Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {metrics.map((metric, index) => {
            const Icon = metric.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Card className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className={`w-12 h-12 bg-gradient-to-br ${metric.color} rounded-lg flex items-center justify-center`}>
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <span className="text-green-600">{metric.change}</span>
                    </div>
                    <h3 className="text-slate-900">{metric.value}</h3>
                    <p className="text-slate-600">{metric.title}</p>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Charts Row 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>Weekly Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={weeklyData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="day" stroke="#64748b" />
                    <YAxis stroke="#64748b" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#fff', 
                        border: '1px solid #e2e8f0',
                        borderRadius: '8px'
                      }} 
                    />
                    <Legend />
                    <Bar dataKey="completed" fill="#3b82f6" radius={[8, 8, 0, 0]} />
                    <Bar dataKey="pending" fill="#f59e0b" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>Monthly Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={monthlyTrend}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="month" stroke="#64748b" />
                    <YAxis stroke="#64748b" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#fff', 
                        border: '1px solid #e2e8f0',
                        borderRadius: '8px'
                      }} 
                    />
                    <Area 
                      type="monotone" 
                      dataKey="value" 
                      stroke="#3b82f6" 
                      fill="url(#colorGradient)"
                      strokeWidth={2}
                    />
                    <defs>
                      <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.8} />
                        <stop offset="100%" stopColor="#3b82f6" stopOpacity={0.1} />
                      </linearGradient>
                    </defs>
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Charts Row 2 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>Project Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={projectDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {projectDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>Team Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {teamPerformance.map((member, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-900">{member.name}</span>
                        <span className="text-slate-600">{member.tasks} tasks</span>
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-2">
                        <div
                          className="bg-gradient-to-r from-blue-600 to-indigo-600 h-2 rounded-full transition-all duration-500"
                          style={{ width: `${member.efficiency}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
