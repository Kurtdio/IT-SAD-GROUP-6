import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Badge } from './ui/badge';
import { Mail, MapPin, Calendar, Award, TrendingUp, Target } from 'lucide-react';
import { motion } from 'motion/react';

export default function Profile() {
  const achievements = [
    { title: 'Early Adopter', icon: Award, color: 'from-blue-600 to-indigo-600' },
    { title: 'Team Player', icon: TrendingUp, color: 'from-green-600 to-emerald-600' },
    { title: 'Goal Crusher', icon: Target, color: 'from-purple-600 to-pink-600' }
  ];

  const stats = [
    { label: 'Projects', value: '24' },
    { label: 'Completed', value: '152' },
    { label: 'In Progress', value: '8' },
    { label: 'Team Members', value: '12' }
  ];

  const recentActivity = [
    { action: 'Completed task', project: 'Website Redesign', time: '2 hours ago' },
    { action: 'Created new project', project: 'Mobile App', time: '5 hours ago' },
    { action: 'Updated status', project: 'API Integration', time: '1 day ago' },
    { action: 'Added comment', project: 'Marketing Campaign', time: '2 days ago' }
  ];

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-slate-900 mb-2">Profile</h1>
          <p className="text-slate-600">Manage your personal information and preferences</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="lg:col-span-1 space-y-6">
            {/* Profile Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <Avatar className="w-24 h-24 mx-auto mb-4">
                      <AvatarFallback className="bg-gradient-to-br from-blue-600 to-indigo-600 text-white">
                        JD
                      </AvatarFallback>
                    </Avatar>
                    <h2 className="text-slate-900 mb-1">John Doe</h2>
                    <p className="text-slate-600 mb-4">Product Manager</p>
                    <Badge className="mb-4 bg-green-100 text-green-700">Active</Badge>
                    
                    <div className="space-y-2 text-slate-600">
                      <div className="flex items-center justify-center gap-2">
                        <Mail className="h-4 w-4" />
                        <span>john.doe@example.com</span>
                      </div>
                      <div className="flex items-center justify-center gap-2">
                        <MapPin className="h-4 w-4" />
                        <span>San Francisco, CA</span>
                      </div>
                      <div className="flex items-center justify-center gap-2">
                        <Calendar className="h-4 w-4" />
                        <span>Joined Jan 2024</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Stats Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Statistics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    {stats.map((stat, index) => (
                      <div key={index} className="text-center p-3 bg-slate-50 rounded-lg">
                        <div className="text-slate-900 mb-1">{stat.value}</div>
                        <div className="text-slate-600">{stat.label}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Achievements */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.2 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Achievements</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {achievements.map((achievement, index) => {
                      const Icon = achievement.icon;
                      return (
                        <div key={index} className="flex items-center gap-3">
                          <div className={`w-10 h-10 bg-gradient-to-br ${achievement.color} rounded-lg flex items-center justify-center`}>
                            <Icon className="h-5 w-5 text-white" />
                          </div>
                          <span className="text-slate-900">{achievement.title}</span>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Right Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Edit Profile Form */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Personal Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <form className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="firstName">First Name</Label>
                        <Input id="firstName" defaultValue="John" className="mt-2" />
                      </div>
                      <div>
                        <Label htmlFor="lastName">Last Name</Label>
                        <Input id="lastName" defaultValue="Doe" className="mt-2" />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" defaultValue="john.doe@example.com" className="mt-2" />
                    </div>

                    <div>
                      <Label htmlFor="role">Role</Label>
                      <Input id="role" defaultValue="Product Manager" className="mt-2" />
                    </div>

                    <div>
                      <Label htmlFor="location">Location</Label>
                      <Input id="location" defaultValue="San Francisco, CA" className="mt-2" />
                    </div>

                    <div>
                      <Label htmlFor="bio">Bio</Label>
                      <Textarea 
                        id="bio" 
                        placeholder="Tell us about yourself..." 
                        className="mt-2 min-h-[100px]"
                        defaultValue="Passionate product manager with 5+ years of experience in building innovative solutions."
                      />
                    </div>

                    <div className="flex gap-4">
                      <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                        Save Changes
                      </Button>
                      <Button variant="outline">Cancel</Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </motion.div>

            {/* Recent Activity */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.2 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentActivity.map((activity, index) => (
                      <div 
                        key={index} 
                        className="flex items-start gap-4 p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors"
                      >
                        <div className="w-2 h-2 bg-blue-600 rounded-full mt-2" />
                        <div className="flex-1">
                          <p className="text-slate-900">
                            {activity.action} in <span className="text-blue-600">{activity.project}</span>
                          </p>
                          <p className="text-slate-500">{activity.time}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
