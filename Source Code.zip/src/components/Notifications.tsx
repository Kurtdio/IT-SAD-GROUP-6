import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Bell, CheckCheck, Trash2, MessageSquare, UserPlus, AlertCircle, Calendar } from 'lucide-react';
import { motion } from 'motion/react';

export default function Notifications() {
  const notifications = [
    {
      id: 1,
      type: 'message',
      icon: MessageSquare,
      title: 'New comment on Website Redesign',
      description: 'John Doe commented: "Great progress on the homepage!"',
      time: '5 minutes ago',
      read: false,
      color: 'from-blue-600 to-indigo-600'
    },
    {
      id: 2,
      type: 'user',
      icon: UserPlus,
      title: 'New team member added',
      description: 'Sarah Williams joined the Mobile App project',
      time: '2 hours ago',
      read: false,
      color: 'from-green-600 to-emerald-600'
    },
    {
      id: 3,
      type: 'alert',
      icon: AlertCircle,
      title: 'Task deadline approaching',
      description: 'API Integration task is due in 2 days',
      time: '4 hours ago',
      read: false,
      color: 'from-amber-600 to-orange-600'
    },
    {
      id: 4,
      type: 'calendar',
      icon: Calendar,
      title: 'Meeting reminder',
      description: 'Team standup meeting in 1 hour',
      time: '6 hours ago',
      read: true,
      color: 'from-purple-600 to-pink-600'
    },
    {
      id: 5,
      type: 'message',
      icon: MessageSquare,
      title: 'Project status updated',
      description: 'Marketing Campaign moved to "In Progress"',
      time: '1 day ago',
      read: true,
      color: 'from-blue-600 to-indigo-600'
    },
    {
      id: 6,
      type: 'user',
      icon: UserPlus,
      title: 'Task assigned to you',
      description: 'You have been assigned to "Database Optimization"',
      time: '2 days ago',
      read: true,
      color: 'from-green-600 to-emerald-600'
    },
    {
      id: 7,
      type: 'alert',
      icon: AlertCircle,
      title: 'Task overdue',
      description: 'Code Review task is 1 day overdue',
      time: '3 days ago',
      read: true,
      color: 'from-red-600 to-pink-600'
    },
    {
      id: 8,
      type: 'calendar',
      icon: Calendar,
      title: 'Project milestone reached',
      description: 'Mobile App reached 75% completion',
      time: '4 days ago',
      read: true,
      color: 'from-purple-600 to-pink-600'
    }
  ];

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
          <div>
            <h1 className="text-slate-900 mb-2">Notifications</h1>
            <p className="text-slate-600">
              You have {unreadCount} unread notification{unreadCount !== 1 ? 's' : ''}
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm">
              <CheckCheck className="h-4 w-4 mr-2" />
              Mark all read
            </Button>
            <Button variant="outline" size="sm">
              <Trash2 className="h-4 w-4 mr-2" />
              Clear all
            </Button>
          </div>
        </div>

        {/* Notifications List */}
        <div className="space-y-3">
          {notifications.map((notification, index) => {
            const Icon = notification.icon;
            return (
              <motion.div
                key={notification.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Card 
                  className={`hover:shadow-lg transition-all duration-300 cursor-pointer ${
                    !notification.read ? 'bg-blue-50/50 border-blue-200' : ''
                  }`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className={`w-12 h-12 bg-gradient-to-br ${notification.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2 mb-1">
                          <h3 className="text-slate-900">
                            {notification.title}
                            {!notification.read && (
                              <span className="ml-2 inline-block w-2 h-2 bg-blue-600 rounded-full" />
                            )}
                          </h3>
                          <span className="text-slate-500 whitespace-nowrap">
                            {notification.time}
                          </span>
                        </div>
                        <p className="text-slate-600 mb-3">
                          {notification.description}
                        </p>
                        
                        <div className="flex items-center gap-2">
                          {!notification.read && (
                            <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-700 hover:bg-blue-50">
                              Mark as read
                            </Button>
                          )}
                          <Button variant="ghost" size="sm" className="text-slate-600 hover:text-red-600 hover:bg-red-50">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Empty State (if no notifications) */}
        {notifications.length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Bell className="h-8 w-8 text-slate-400" />
            </div>
            <h3 className="text-slate-900 mb-2">No notifications</h3>
            <p className="text-slate-600">
              You're all caught up! Check back later for updates.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
