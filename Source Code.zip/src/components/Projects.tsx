import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Plus, Search, Filter, MoreVertical, Calendar, Users, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

export default function Projects() {
  const [searchQuery, setSearchQuery] = useState('');

  const projects = [
    {
      id: 1,
      name: 'E-Commerce Platform',
      description: 'Building a modern e-commerce solution with React and Node.js',
      status: 'In Progress',
      progress: 65,
      dueDate: 'Dec 15, 2025',
      team: 5,
      tasks: { completed: 24, total: 37 },
      color: 'from-blue-600 to-indigo-600'
    },
    {
      id: 2,
      name: 'Mobile App Development',
      description: 'Cross-platform mobile application for iOS and Android',
      status: 'Review',
      progress: 90,
      dueDate: 'Dec 10, 2025',
      team: 4,
      tasks: { completed: 45, total: 50 },
      color: 'from-purple-600 to-pink-600'
    },
    {
      id: 3,
      name: 'Marketing Campaign',
      description: 'Q4 marketing strategy and content creation',
      status: 'Planning',
      progress: 30,
      dueDate: 'Dec 20, 2025',
      team: 3,
      tasks: { completed: 12, total: 40 },
      color: 'from-amber-600 to-orange-600'
    },
    {
      id: 4,
      name: 'API Integration',
      description: 'Third-party service integrations and documentation',
      status: 'Completed',
      progress: 100,
      dueDate: 'Dec 5, 2025',
      team: 2,
      tasks: { completed: 28, total: 28 },
      color: 'from-green-600 to-emerald-600'
    },
    {
      id: 5,
      name: 'UI/UX Redesign',
      description: 'Complete redesign of the user interface and experience',
      status: 'In Progress',
      progress: 45,
      dueDate: 'Jan 5, 2026',
      team: 6,
      tasks: { completed: 18, total: 40 },
      color: 'from-cyan-600 to-blue-600'
    },
    {
      id: 6,
      name: 'Database Migration',
      description: 'Migrating from PostgreSQL to a more scalable solution',
      status: 'Planning',
      progress: 15,
      dueDate: 'Jan 15, 2026',
      team: 3,
      tasks: { completed: 3, total: 20 },
      color: 'from-indigo-600 to-purple-600'
    }
  ];

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
          <div>
            <h1 className="text-slate-900 mb-2">Projects</h1>
            <p className="text-slate-600">Manage and track all your projects in one place</p>
          </div>
          <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
            <Plus className="h-5 w-5 mr-2" />
            New Project
          </Button>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
            <Input
              placeholder="Search projects..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button variant="outline">
            <Filter className="h-5 w-5 mr-2" />
            Filter
          </Button>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <Card className="hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer">
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <div className={`w-12 h-12 bg-gradient-to-br ${project.color} rounded-lg`} />
                    <Button variant="ghost" size="sm">
                      <MoreVertical className="h-5 w-5" />
                    </Button>
                  </div>
                  <CardTitle className="mb-2">{project.name}</CardTitle>
                  <p className="text-slate-600">{project.description}</p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* Status Badge */}
                    <Badge
                      className={`${
                        project.status === 'Completed' ? 'bg-green-100 text-green-700' :
                        project.status === 'In Progress' ? 'bg-blue-100 text-blue-700' :
                        project.status === 'Review' ? 'bg-purple-100 text-purple-700' :
                        'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {project.status}
                    </Badge>

                    {/* Progress */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-slate-600">Progress</span>
                        <span className="text-slate-900">{project.progress}%</span>
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-2">
                        <div
                          className={`bg-gradient-to-r ${project.color} h-2 rounded-full transition-all duration-500`}
                          style={{ width: `${project.progress}%` }}
                        />
                      </div>
                    </div>

                    {/* Stats */}
                    <div className="flex items-center justify-between pt-4 border-t border-slate-200">
                      <div className="flex items-center gap-4 text-slate-600">
                        <div className="flex items-center gap-1">
                          <CheckCircle2 className="h-4 w-4" />
                          <span>{project.tasks.completed}/{project.tasks.total}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4" />
                          <span>{project.team}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 text-slate-600">
                        <Calendar className="h-4 w-4" />
                        <span>{project.dueDate}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
