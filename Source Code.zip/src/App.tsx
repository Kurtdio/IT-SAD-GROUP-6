import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import Splash from './components/studyflow/Splash';
import Login from './components/studyflow/Login';
import SignUp from './components/studyflow/SignUp';
import Dashboard from './components/studyflow/Dashboard';
import TasksList from './components/studyflow/TasksList';
import AddTask from './components/studyflow/AddTask';
import Profile from './components/studyflow/Profile';
import Settings from './components/studyflow/Settings';
import About from './components/studyflow/About';
import Notifications from './components/studyflow/Notifications';
import Statistics from './components/studyflow/Statistics';
import Layout from './components/studyflow/Layout';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2500);
    return () => clearTimeout(timer);
  }, []);

  if (showSplash) {
    return <Splash />;
  }

  return (
    <Router>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={isAuthenticated ? <Navigate to="/dashboard" /> : <Navigate to="/login" />} />
        <Route path="/preview_page.html" element={isAuthenticated ? <Navigate to="/dashboard" /> : <Navigate to="/login" />} />
        <Route path="/login" element={<Login setIsAuthenticated={setIsAuthenticated} />} />
        <Route path="/signup" element={<SignUp setIsAuthenticated={setIsAuthenticated} />} />
        
        {/* Protected Routes */}
        <Route element={<Layout isAuthenticated={isAuthenticated} setIsAuthenticated={setIsAuthenticated} />}>
          <Route 
            path="/dashboard" 
            element={isAuthenticated ? <Dashboard /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/tasks" 
            element={isAuthenticated ? <TasksList /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/add-task" 
            element={isAuthenticated ? <AddTask /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/edit-task/:id" 
            element={isAuthenticated ? <AddTask /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/notifications" 
            element={isAuthenticated ? <Notifications /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/statistics" 
            element={isAuthenticated ? <Statistics /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/profile" 
            element={isAuthenticated ? <Profile /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/settings" 
            element={isAuthenticated ? <Settings /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/about" 
            element={isAuthenticated ? <About /> : <Navigate to="/login" />} 
          />
        </Route>
        
        {/* Catch-all route */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}
